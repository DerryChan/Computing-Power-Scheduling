# 跨境算力调度 PoC 真实调度补齐报告

时间：2026-08-11
模式：真实调度（新加坡控制面 → 海南/重庆 node agent → ResNet50 冻结包 GPU 推理）

## 环境
- 新加坡控制面 UI：http://43.106.50.98:8080/
- 海南：1×RTX 4090，agent `172.18.20.6:8000`（经隧道 `127.0.0.1:18000`），Python `/srv/conda/envs/l1poc/bin/python` + torch cu124
- 重庆：4×RTX 4070，agent `:8000`
- Bundle：`/opt/l1-poc-bundle`（4096 样本 / 8 分片 / resnet50_frozen.pth）

## 关键结果
| 用例 | 结果 | 说明 |
|------|------|------|
| TC01 | SUCCEEDED 4/4 | 海南+重庆，完整性校验通过 |
| TC02 | REJECTED HTTP200 | 错误 Bearer → 两地 agent 401 |
| TC03 | REJECTED HTTP200 | 非授权端口探针被阻断 |
| TC04 | REJECTED HTTP200 | 故意哈希不一致拒绝建任务 |
| DT01 ×3 | SUCCEEDED 8/8 ×3 | 两地真实分片；merge 4096/4096 unique |
| DT03 | SUCCEEDED 1/1 | 16GB 约束调度至海南 4090 |

## 说明与未闭环项
- 海南现场为 1×4090（非文档双卡）
- 链路为公网+反向隧道，非正式 VPN/OTN SLA 基线
- TC30 24h 墙钟稳定性未跑满；已提供短稳场景 `tc30_stability_short`
- 参考比对：`predictions_all.jsonl` 已就位；语义 top1 比对见本机执行日志

